import React, { Component } from 'react'

class Homepage extends Component {
    render() {
        return (
            <div>
                <div>
                    <h1>About Us</h1>
                    <p>Some text</p>
                </div>
                <div>
                    <h1>Contact Us</h1>
                    <p>Some more text</p>
                </div>
            </div>
        )
    }
}

export default Homepage;