import React from "react";
import {shallow, mount} from "enzyme";
import Enzyme from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import UpcomingBookings from "../../components/Bookings/UpcomingBookings.js";

Enzyme.configure({adapter: new Adapter()});

describe('Upcoming Booking Testing', () => {
    let wrapper;
    beforeEach(() => {
        wrapper = shallow(<UpcomingBookings/>);

    })

    it('should render page title', () => {
        const title = "Upcoming Bookings";
        const pageHeading = wrapper.find('h5').text();
        expect(pageHeading).toEqual(title);
    });
})
